# Rover5 library for Arduino MEGA2560

The Robot has a number of built in sensors and actuators. The library is designed to easily access the robot's functionality.

For more information about this library please visit us at:
https://git.webhosting.rug.nl/DTPA/Mechatronics_2021

# License

Copyright (c) RUG DTPA 2021. All right reserved.

