/*
* 
* Rover5 library for Arduino MEGA2560 based Small Robot Controller rev. 1.2.
*
*/

#include "Rover5lib.h"
#include "digitalWriteFast.h"
#include <Servo.h>

Rover5ControlBoard::Rover5ControlBoard() {}

void Rover5ControlBoard::begin(bool _battMgmt) {
	pinMode(MOTOR_nFAULT, INPUT);
	//digitalWrite(MOTOR_nFAULT, LOW);  // turn on pull-up resistor
	pinMode(MOTOR_nRST, OUTPUT); // reset motor stage
	digitalWrite(MOTOR_nSLEEP, LOW); // start in sleep mode
	pinMode(MOTOR_nSLEEP, OUTPUT); // sleep motor stage
	digitalWrite(MOTOR_nRST, HIGH);  // reset motor drivers
	pinMode(MOTOR_ENABLE12, OUTPUT);
	digitalWrite(MOTOR_ENABLE12, LOW);
	pinMode(MOTOR_ENABLE34, OUTPUT);
	digitalWrite(MOTOR_ENABLE34, LOW);
	attachInterrupt(INT_PWR_OFF, Isr_PowerOff, FALLING);
	pinMode(PIN_PWR_ON, OUTPUT);
	pinMode(PIN_BUZZER, OUTPUT);

	// Quadrature encoders
	// Left encoder
	pinMode(ENC_LEFT_CHA, INPUT);      // sets pin A as input
	//digitalWrite(ENC_LEFT_CHA, LOW);  // turn on pull-up resistors
	pinMode(ENC_LEFT_CHB, INPUT);      // sets pin B as input
	//digitalWrite(ENC_LEFT_CHB, LOW);  // turn on pull-up resistors
	attachInterrupt(INT_ENC_LEFT, Isr_EncoderLeft, CHANGE);
	// Right encoder
	pinMode(ENC_RIGHT_CHA, INPUT);      // sets pin A as input
	//digitalWrite(ENC_RIGHT_CHA, LOW);  // turn on pull-up resistors
	pinMode(ENC_RIGHT_CHB, INPUT);      // sets pin B as input
	//digitalWrite(ENC_RIGHT_CHB, LOW);  // turn on pull-up resistors
	attachInterrupt(INT_ENC_RIGHT, Isr_EncoderRight, CHANGE);

	// Switches
	pinMode(PIN_SWITCH_A, OUTPUT);
	pinMode(PIN_SWITCH_B, OUTPUT);

    //Servo's
	servo1.attach(26);  // Attach servo on pin 26 to the servo object.
	servo2.attach(27);
	//servo3.attach(28);
	//servo4.attach(29);

	//Sonar
	pinMode(PIN_SONAR_TRIG, OUTPUT);
	digitalWrite(PIN_SONAR_TRIG, LOW);
	attachInterrupt(INT_SONAR_ECHO, Isr_SonarEcho, FALLING);

	// modify PWM frequency Motor L+R outputs:
	//TCCR1B = (TCCR1B & B11111000) | B00000010; //set PWM frequency of 3921.16 Hz for pin 11 and pin 12.
	//TCCR2B = (TCCR2B & B11111000) | B00000010; //set PWM frequency of 3921.16 Hz for pin 9 and pin 10.
	TCCR1B = (TCCR1B & B11111000) | B00000001; //set PWM frequency of 31372.55 Hz for pin 11 and pin 12.
	TCCR2B = (TCCR2B & B11111000) | B00000001; //set PWM frequency of 31372.55 Hz for pin 9 and pin 10.

	battMgmt = _battMgmt;
	sumTap1 = BATT_MVAVG_SIZE * analogRead(PIN_VSCALED_3V7); //fill the moving average buffers
	sumTap12 = BATT_MVAVG_SIZE * analogRead(PIN_VSCALED_7V4);
	sumTap123 = BATT_MVAVG_SIZE * analogRead(PIN_VSCALED_11V1);

	digitalWrite(PIN_BUZZER, HIGH);
	digitalWrite(PIN_PWR_ON, HIGH); // Power on bootstrap.
	delay(250);
	digitalWrite(PIN_BUZZER, LOW);
}


void Rover5ControlBoard::update() {
	// battery management
	sumTap1 -= sumTap1 / BATT_MVAVG_SIZE; // subtract the current average from the sum of ADC-values.
	sumTap1 += analogRead(PIN_VSCALED_3V7); // read the new value and add it to the sum
	sumTap12 -= sumTap12 / BATT_MVAVG_SIZE;
	sumTap12 += analogRead(PIN_VSCALED_7V4);
	sumTap123 -= sumTap123 / BATT_MVAVG_SIZE;
	sumTap123 += analogRead(PIN_VSCALED_11V1);
	if( cnt & 0b01000 ) {
		float Vtap1 = (float)sumTap1/BATT_MVAVG_SIZE * VSCALE_TAP1;
		float Vtap2 = (float)sumTap12/BATT_MVAVG_SIZE * VSCALE_TAP12;
		float Vtap3 = (float)sumTap123/BATT_MVAVG_SIZE * VSCALE_TAP123;
		vTap[0] = round(Vtap1);
		vTap[1] = round(Vtap2);
		vTap[2] = round(Vtap3);
		vCell[0] = round(Vtap1);
		vCell[1] = round(Vtap2 - Vtap1);
		vCell[2] = round(Vtap3 - Vtap2);

		if( (vCell[0] <= BATT_VCUTOFF) || (vCell[1] <= BATT_VCUTOFF) || (vCell[2] <= BATT_VCUTOFF) ) {
			if(battMgmt) { powerOff(); }
		}
		if( (vCell[0] <= BATT_VLOW) || (vCell[1] <= BATT_VLOW) || (vCell[2] <= BATT_VLOW) ) {
			if(battMgmt) { battLow = true; }
		}
		else {
			battLow = false;
		}
	}

	if( battLow ) {
	    if( cnt & 0b100 ) {
		  digitalWrite(PIN_BUZZER, HIGH);
	    }
		else {
			digitalWrite(PIN_BUZZER, LOW);
		}
	}

	if( cnt & 0b1000 ) {
		digitalWrite(PIN_LED, HIGH);
	}
	else {
		digitalWrite(PIN_LED, LOW);
	}

	if( buzzOn ) {
	    if( cnt & 0b1000 ) {
		  digitalWrite(PIN_BUZZER, HIGH);
		  buzzNow = true;
	    }
		else {
			if( buzzNow ) {
			  digitalWrite(PIN_BUZZER, LOW);
			  buzzOn = false;
			  buzzNow = false;
			}
		}
	}

	cnt++;
}


void Rover5ControlBoard::motorsStart() {
	digitalWrite(MOTOR_nSLEEP, HIGH); // enable motor drivers
    digitalWrite(MOTOR_ENABLE12, HIGH);
    digitalWrite(MOTOR_ENABLE34, HIGH);
    analogWrite(MOTOR_LEFT_PWMA, 128); // Dummy write to enable PWM outputs with duty-cycle of 50%.
    analogWrite(MOTOR_LEFT_PWMB, 128);
    analogWrite(MOTOR_RIGHT_PWMA, 128);
    analogWrite(MOTOR_RIGHT_PWMB, 128);
}


void Rover5ControlBoard::motorsStop() {
	analogWrite(MOTOR_LEFT_PWMA, 0);  // Dummy write switch off PWM
	analogWrite(MOTOR_LEFT_PWMB, 0);
	analogWrite(MOTOR_RIGHT_PWMA, 0);
	analogWrite(MOTOR_RIGHT_PWMB, 0);
	digitalWrite(MOTOR_ENABLE12, LOW);
	digitalWrite(MOTOR_ENABLE34, LOW);
	digitalWrite(MOTOR_nSLEEP, LOW); // disable drivers
}


void Rover5ControlBoard::motorsWrite(int _pwmLeft, int _pwmRight) {
	// PWM-update by direct register write
	OCR1A = 128 - constrain(_pwmLeft, -MOTOR_PWM_LIM, MOTOR_PWM_LIM);; //MOTOR_LEFT_PWMA pin
	OCR1B = 127 + constrain(_pwmLeft, -MOTOR_PWM_LIM, MOTOR_PWM_LIM);; //MOTOR_LEFT_PWMB pin
	OCR2A = 128 - constrain(_pwmRight, -MOTOR_PWM_LIM, MOTOR_PWM_LIM);; //MOTOR_RIGHT_PWMA pin
	OCR2B = 127 + constrain(_pwmRight, -MOTOR_PWM_LIM, MOTOR_PWM_LIM);; //MOTOR_RIGHT_PWMB pin
}


void Rover5ControlBoard::powerOff() {
	analogWrite(MOTOR_LEFT_PWMA, 0);  //switch off PWM
	analogWrite(MOTOR_LEFT_PWMB, 0);
	analogWrite(MOTOR_RIGHT_PWMA, 0);
	analogWrite(MOTOR_RIGHT_PWMB, 0);
	digitalWrite(MOTOR_ENABLE12, LOW);
	digitalWrite(MOTOR_ENABLE34, LOW);
	digitalWrite(MOTOR_nSLEEP, LOW); //disable drivers
	digitalWrite(PIN_BUZZER, HIGH);
	delay(500);
	digitalWrite(PIN_BUZZER, LOW);
	digitalWrite(PIN_PWR_ON, LOW); // power down
	while(true) {;} //Show stops here.
}


void Rover5ControlBoard::powerSwitch(int _channel, bool _state) {
	if(_channel == 1) {
		digitalWrite(PIN_SWITCH_A, _state);
	}
	if(_channel == 2) {
		digitalWrite(PIN_SWITCH_B, _state);
	}
}


void Rover5ControlBoard::servoPan(int _angle) {
	servo1.write(_angle);
}


void Rover5ControlBoard::servoTilt(int _angle) {
	servo2.write(_angle);
}


void Rover5ControlBoard::readEncoders() {
	encPos[0] = posLeft;
	encPos[1] = posRight;

	// Calculate delta-position each sample interval.
	encDeltaStep[0] = posLeft - posLeftPrev;
	posLeftPrev = posLeft;
	encDeltaStep[1] = posRight - posRightPrev;
	posRightPrev = posRight;
}


void Rover5ControlBoard::triggerSonar() {
	//Trigger the Sonar and reset the ping time:
	digitalWriteFast(PIN_SONAR_TRIG, HIGH);
	delayMicroseconds(10); //wait for 10us.
	digitalWriteFast(PIN_SONAR_TRIG, LOW);
	tp0 = micros(); //ping = current time
}


void Rover5ControlBoard::readSonar() {
	sonarPing = ping;
}


void Rover5ControlBoard::buzz() {
	buzzOn = true;
}




/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   Power button OFF Interrupt Service Routine
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
static void Rover5ControlBoard::Isr_PowerOff() {
  analogWrite(MOTOR_LEFT_PWMA, 0);  //switch off PWM
  analogWrite(MOTOR_LEFT_PWMB, 0);
  analogWrite(MOTOR_RIGHT_PWMA, 0);
  analogWrite(MOTOR_RIGHT_PWMB, 0);
  digitalWrite(MOTOR_ENABLE12, LOW);
  digitalWrite(MOTOR_ENABLE34, LOW);
  digitalWrite(MOTOR_nSLEEP, LOW); //disable drivers
  digitalWrite(PIN_BUZZER, HIGH);
  delay(500);
  digitalWrite(PIN_BUZZER, LOW);
  digitalWrite(PIN_PWR_ON, LOW); // power down
  while(true) {;} //Show stops here.
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *   Sonar echo Interrupt Service Routine
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
static void Rover5ControlBoard::Isr_SonarEcho() {
  ping = micros() - tp0; // Record sonar ping time.
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*   Quadrature encoder Interrupt Service Routines
*
*      This encoder readout method suggested by Russell, was found at the Dagu Robot Forum
*      http://bbs.dagurobot.com/forum.php?mod=viewthread&tid=4
*      Here digitalReadFast() is used to speed it up.
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
static void Rover5ControlBoard::Isr_EncoderLeft() {
#ifdef LEFT_ENC_IS_REVERSED
  encTicksLeft_old = encTicksLeft_new;
  encTicksLeft_new = digitalReadFast(ENC_LEFT_CHA) * 2 + digitalReadFast(ENC_LEFT_CHB);
  posLeft -= QEM[encTicksLeft_old * 4 + encTicksLeft_new];
#else
  encTicksLeft_old = encTicksLeft_new;
  encTicksLeft_new = digitalReadFast(ENC_LEFT_CHA) * 2 + digitalReadFast(ENC_LEFT_CHB);
  posLeft += QEM[encTicksLeft_old * 4 + encTicksLeft_new];
#endif
}

static void Rover5ControlBoard::Isr_EncoderRight() {
#ifdef RIGHT_ENC_IS_REVERSED
  encTicksRight_old = encTicksRight_new;
  encTicksRight_new = digitalReadFast(ENC_RIGHT_CHA) * 2 + digitalReadFast(ENC_RIGHT_CHB);
  posRight -= QEM[encTicksRight_old * 4 + encTicksRight_new];
#else
  encTicksRight_old = encTicksRight_new;
  encTicksRight_new = digitalReadFast(ENC_RIGHT_CHA) * 2 + digitalReadFast(ENC_RIGHT_CHB);
  posRight += QEM[encTicksRight_old * 4 + encTicksRight_new];
#endif
}


Rover5ControlBoard Rover=Rover5ControlBoard();
static volatile unsigned char Rover5ControlBoard::encTicksLeft_new;
static volatile unsigned char Rover5ControlBoard::encTicksLeft_old;
static volatile long Rover5ControlBoard::posLeft;
static volatile unsigned char Rover5ControlBoard::encTicksRight_new;
static volatile unsigned char Rover5ControlBoard::encTicksRight_old;
static volatile long Rover5ControlBoard::posRight;
static volatile long Rover5ControlBoard::ping;
static volatile long Rover5ControlBoard::tp0;
