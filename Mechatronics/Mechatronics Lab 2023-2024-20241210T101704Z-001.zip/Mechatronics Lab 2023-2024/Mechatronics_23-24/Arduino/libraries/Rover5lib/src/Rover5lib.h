/*
 *
 * Rover5 library for Arduino MEGA2560 based Small Robot Controller revision 1.1 and 1.2.
 *
 * Rover-5 chassis parameters:
 * Wheel base width = 0.245m (use 0.194 with tracks).
 * Wheel radius = 32.5mm (use 0.032 with track wheels).
 *
 * The Encoder(s) generate 1000 pulses each 3 wheel revolutions.
 * 1rev/s = 4*333.33 = 1333.33 pps. At 20Hz sample rate: 1333.33/20 = 66.67 pulses/sample.
 * 1rev/s = 2*pi*r/s= 0.2m/s. 1m/s=1333.33*5/20 = 333.33 pulses/sample-interval.
 *
 */

#ifndef Rover5lib_h
#define Rover5lib_h
#include <Servo.h>

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

// Quadrature encoder left
#define INT_ENC_LEFT 5 //PIN 18, INT 3, ATTACH 5
#define ENC_LEFT_CHA 24
#define ENC_LEFT_CHB 25
#define LEFT_ENC_IS_REVERSED //reverse for dtpa robot?

// Quadrature encoder right
#define INT_ENC_RIGHT 4 //PIN 19, INT 2, ATTACH 4
#define ENC_RIGHT_CHA 22
#define ENC_RIGHT_CHB 23
//#define RIGHT_ENC_IS_REVERSED

const int QEM[16] = { 0, -1, 1, 2, 1, 0, 2, -1, -1, 2, 0, 1, 2, 1, -1, 0 }; // Quadrature decoding matrix

// other pins
#define PIN_LED 13
#define PIN_BUZZER 37
#define PIN_PWR_ON 36 // output
#define INT_PWR_OFF 0 // PIN 2, INT 4, ATTACH 0
#define PIN_SWITCH_A 34
#define PIN_SWITCH_B 35

//Battery management
#define PIN_VSCALED_11V1 A10
#define PIN_VSCALED_7V4 A9
#define PIN_VSCALED_3V7 A8
#define BATT_MVAVG_SIZE 4	// Moving average window size in number of samples. Use powers of 2.
const float VREF = 5020.0; //ADC reference voltage
const float VSCALE_TAP1 = VREF/1024.0; // mV = adc_value * SCALE_CELL1
const float VSCALE_TAP12 = (12.0 + 22.0)/22.0 * VREF/1024.0; // mV = adc_value * SCALE_CELL12
const float VSCALE_TAP123 = (22.0 + 15.0)/15.0 * VREF/1024.0; // mV = adc_value * SCALE_CELL123
const int BATT_VLOW = 3300; // Threshold cell voltages in mV's.
const int BATT_VCUTOFF = 3100;

// Motors
#define MOTOR_nRST 30
#define MOTOR_nSLEEP 31
#define MOTOR_nFAULT 32
#define MOTOR_ENABLE12 5
#define MOTOR_ENABLE34 6
#define MOTOR_LEFT_PWMA 11
#define MOTOR_LEFT_PWMB 12
#define MOTOR_RIGHT_PWMA 10
#define MOTOR_RIGHT_PWMB 9
#define MOTOR_PWM_LIM 80 //abs. max PWM limit to limit max. (average) motor voltage. Vbatt_max=12V, Vmotor_max=7.5V.

// optional sonar
#define PIN_SONAR_TRIG 4 // Arduino pin tied to trigger pin of the ultrasonic sensor.
#define INT_SONAR_ECHO 1 //PIN3, INT5, ATTACHINT1, Arduino pin tied to echo pin of the ultrasonic sensor.


class Rover5ControlBoard {
	static volatile unsigned char encTicksLeft_old, encTicksLeft_new;
	static volatile unsigned char encTicksRight_old, encTicksRight_new;
	static volatile long posLeft, posRight;
	static volatile long ping; //sonar ping time
	static volatile long tp0; //sonar start time

	public:
		Rover5ControlBoard();
		void begin(bool);
		int vTap[3];
		int vCell[3];
		bool battLow;
		void update();
		void motorsStart();
		void motorsStop();
		void motorsWrite(int, int);
		void powerOff();
		void powerSwitch(int, bool);
		void servoPan(int);
		void servoTilt(int);
		long encPos[2];
		long encDeltaStep[2];
		void readEncoders(); //readRawEnc, readPos
		void triggerSonar();
		long sonarPing;
		void readSonar();
		void buzz(); //sound buzzer

		static void Isr_PowerOff();
		static void Isr_EncoderLeft();
		static void Isr_EncoderRight();
		static void Isr_SonarEcho();

	private:
		long posLeftPrev; //memorizing previous encoder positions
		long posRightPrev;
		int cnt;
		bool battMgmt;
		bool buzzOn, buzzNow;
		unsigned int sumTap1, sumTap12, sumTap123;
		// create servo objects to control a servo.
		Servo servo1;
		Servo servo2;
		//Servo servo3;
		//Servo servo4;
};

extern Rover5ControlBoard Rover;

#endif
